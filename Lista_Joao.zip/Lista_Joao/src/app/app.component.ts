import { Component } from '@angular/core';
import { Component } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  
});

export class AppComponent  {
  title = 'listaRu';
  /**Estrutura para o array com os dados dos alunos */
  alunos: Array<any>;
  constructor(){
    this.alunos=[{
      nome:"João Victor Almeida Lira",
      RU: 1900917,
      curso:"Analise e Desenvolvimento de Sistemas",
      nasc:"10/09/1995"
    },


    /*Exemplos para compor o restante do array*/
    {
      nome:"Joana Souza",
      RU: 3423616,
      curso:"Tecnologia em Logistica",
      nasc:"03/12/1988"
    },
    {
      nome:"Mario de Oliveira",
      RU: 3534727,
      curso:"Tecnologia em Design de Games",
      nasc:"09/05/1989"
    },
    {
      nome:"Osama Carlos Silva",
      RU: 4645838,
      curso:"Bacharelado em Jornalismo",
      nasc:"23/09/1995"
    },
    {
      nome:"Rayssa Padilha",
      RU: 4656908,
      curso:"Bacharelado em Engenharia Eletrica",
      nasc:"11/02/1998"
    }];
  }  
}