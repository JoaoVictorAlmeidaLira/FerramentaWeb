Trabalho de Ferramentas de desenvolvimento web!
João Almeida/ 1900917
Problemas no arquivo app.component.ts provavelmente com a lib @angular/compiler